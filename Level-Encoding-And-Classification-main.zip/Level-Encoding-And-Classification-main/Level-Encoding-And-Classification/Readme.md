# Level-Encoding-And-Classification
Level-Encoding-And-Classification on Titanic.csv Dataset
